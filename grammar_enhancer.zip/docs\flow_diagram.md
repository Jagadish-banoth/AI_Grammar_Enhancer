[ Input Text ]
      ↓
[ Phase 6 ] → Fix Subject-Verb Agreement
      ↓
[ Phase 7 ] → Fix Tense Consistency
      ↓
[ Phase 8 ] → Fix Pronouns
      ↓
[ Phase 9 ] → Fix Conjunctions
      ↓
[ Phase 10 ] → Fix Articles
      ↓
[ Final Corrected Output ]

