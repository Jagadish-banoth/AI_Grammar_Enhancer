# tests/test_gramformer.py
import pytest
from src.utils import get_gramformer

@pytest.fixture(scope="session")
def gf():
    """Reuse Gramformer across tests (singleton via conftest.py)"""
    return get_gramformer()

def test_grammar_correction_singular(gf):
    text = "I goes to school"
    corrections = gf.correct(text, max_candidates=1)
    corrected = list(corrections)[0] if corrections else text
    assert "go" in corrected.lower()

def test_grammar_correction_plural(gf):
    text = "The dogs barks loudly."
    corrections = gf.correct(text, max_candidates=1)
    corrected = list(corrections)[0] if corrections else text
    assert "bark" in corrected.lower()

def test_grammar_correction_complex(gf):
    text = "She don't like apples."
    corrections = gf.correct(text, max_candidates=1)
    corrected = list(corrections)[0] if corrections else text
    assert "doesn't" in corrected or "does not" in corrected

def test_grammar_no_change_needed(gf):
    text = "I go to school every day."
    corrections = gf.correct(text, max_candidates=1)
    corrected = list(corrections)[0] if corrections else text
    assert corrected == text