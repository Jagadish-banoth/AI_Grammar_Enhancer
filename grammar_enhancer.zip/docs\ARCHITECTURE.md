# 🧠 Grammar Enhancer — System Architecture

──────────────────────────────────────────────────────────────
                SEQUENTIAL DATA FLOW (PHASE 5 → OUTPUT)
──────────────────────────────────────────────────────────────

     ┌────────────────────────────────────────────┐
     │                PHASE 5 INPUT               │
     │     (Word Order & Sentence Structure)      │
     │   e.g., "hi i is jaga. go to shloo"        │
     └────────────────────────────┬───────────────┘
                                  │
                                  ▼
     ┌────────────────────────────────────────────┐
     │                PIPELINE                    │
     │         (src/pipeline.py — Orchestrator)   │
     │  • Loads all modules                       │
     │  • Passes text sequentially through phases │
     │  • Tracks logs & performance               │
     └────────────────────────────┬───────────────┘
                                  │
                                  ▼
──────────────────────────────────────────────────────────────
                      PHASE EXECUTION SEQUENCE
──────────────────────────────────────────────────────────────

     [ PHASE 6 ]  Subject–Verb Agreement (SVA)
     -----------------------------------------------------------
     • Fix mismatched subjects and verbs  
       → "i is" → "I am"  
       → "He go" → "He goes"
     • Ensures grammatical number consistency

                                  │
                                  ▼
     [ PHASE 7 ]  Tense + Spelling Correction
     -----------------------------------------------------------
     • Normalizes tense consistency  
       → "Yesterday he go" → "Yesterday he went"
     • Corrects spelling  
       → "shloo" → "school"

                                  │
                                  ▼
     [ PHASE 8 ]  Pronoun Agreement
     -----------------------------------------------------------
     • Replaces incorrect or unclear pronouns  
       → "They is" → "They are"  
       → "John said she" → "John said he"

                                  │
                                  ▼
     [ PHASE 9 ]  Conjunction Correction
     -----------------------------------------------------------
     • Removes incorrect starting conjunctions  
       → "And I go" → "I go"  
     • Joins fragmented sentences logically

                                  │
                                  ▼
     [ PHASE 10 ]  Article Correction
     -----------------------------------------------------------
     • Fixes “a/an/the” usage  
       → "a apple" → "an apple"  
       → "He went to school" (adds missing articles)

                                  │
                                  ▼
     ┌────────────────────────────────────────────┐
     │                  OUTPUT                    │
     │           (Phase 11 — Clean Text)           │
     │     e.g., "Hi, I'm Jaga. I go to school."   │
     └────────────────────────────────────────────┘


