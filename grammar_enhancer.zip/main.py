from src.pipeline import GrammarPipeline
from src.utils import get_language_tool, get_spacy_model

# ========================= GLOBAL SINGLETONS =========================
print("Initializing AI Grammar Engine (one-time load)...")

# 1. Load spaCy model once
NLP = get_spacy_model()

# 2. Load LanguageTool offline once
LT_TOOL = get_language_tool()

print("✅ AI Engine Ready (Offline Mode)\n")

# ========================= PIPELINE =========================
pipeline = GrammarPipeline()

# ========================= MAIN =========================
if __name__ == "__main__":
    print("Grammar Enhancer (Phases 6–10)\n")
    input_text = input("Enter your Phase 5 output text:\n> ").strip()

    if not input_text:
        print("No input provided. Exiting.")
    else:
        print("\nRunning full grammar correction pipeline...\n")
        final_output = pipeline.run(input_text)

        print("\nFinal Corrected Output (Phase 11 Ready):\n")
        print(final_output)

    LT_TOOL.close()
